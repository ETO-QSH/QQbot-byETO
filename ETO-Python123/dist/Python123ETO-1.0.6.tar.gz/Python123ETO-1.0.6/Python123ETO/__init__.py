import Python123ETO.info
from Python123ETO.data import data
from Python123ETO.main import parse_data

Q2A = parse_data(data)
